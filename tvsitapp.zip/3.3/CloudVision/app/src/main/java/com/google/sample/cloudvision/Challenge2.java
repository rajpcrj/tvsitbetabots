package com.google.sample.cloudvision;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Challenge2 extends AppCompatActivity {
    static Intent i;
    EditText etdl;
    int challengekey;
    Button btndl;
    Button btnch;
    EditText etch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_challenge2);
        Intent gint = getIntent();
        btndl=findViewById(R.id.btndl);
        btnch=findViewById(R.id.btnch);
        etdl=findViewById(R.id.etdl);
        i= new Intent(getBaseContext(),MainActivity.class);

        etch=findViewById(R.id.edcn);
        btnch=findViewById(R.id.btnch);


        btndl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                challengekey=3;
                Intent int3=new Intent(getBaseContext(),MainActivity.class);
                int3.putExtra("Challenge",challengekey);
                startActivityForResult(int3,3);


            }
        });
        btnch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                challengekey=4;
                Intent int4=new Intent(getBaseContext(),MainActivity.class);
                int4.putExtra("Challenge",challengekey);
                startActivityForResult(int4,4);
            }
        });




    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==3 && resultCode==RESULT_OK){
            String dlstr= data.getStringExtra("result");
            etdl.setText(dlstr);
        }
        else if(requestCode==4 && resultCode==RESULT_OK){
            String chstr= data.getStringExtra("result");
            etch.setText(chstr);
        }
    }
}