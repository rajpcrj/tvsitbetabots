package com.google.sample.cloudvision;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class IdProcessing extends AppCompatActivity {

    TextView tv1;
    ImageView img1;
    public static String rStr="";

    public void startConfigDet(View view) {
    }


    // declaring all the diffrent kinds of data structures to be used
    //pan details
    static  class pDet{
        String name="";
        String pnum="";
        String fname="";
        String dob="";
    }
    // aadhar details
    static  class aDet{
        String name="";
        String dob="";
        String anum="";
        String gender="";
    }
    // voter details class
    static  class vDet{
        String name="";
        String dob="";
        String fnum="";
        String gender="";
    }

    // end of all declarations now declaring various functions to be used for extracting inforations
    // Various loops and regex function for string manipulations


    //1 Verhoeff algorith
    // ********************&&&&&&&&&&&&&&&&&&&&&&&&&&&&&**********************************
    static class VerhoeffAlgorithm {
        static int[][] d = new int[][]
                {
                        {0, 1, 2, 3, 4, 5, 6, 7, 8, 9},
                        {1, 2, 3, 4, 0, 6, 7, 8, 9, 5},
                        {2, 3, 4, 0, 1, 7, 8, 9, 5, 6},
                        {3, 4, 0, 1, 2, 8, 9, 5, 6, 7},
                        {4, 0, 1, 2, 3, 9, 5, 6, 7, 8},
                        {5, 9, 8, 7, 6, 0, 4, 3, 2, 1},
                        {6, 5, 9, 8, 7, 1, 0, 4, 3, 2},
                        {7, 6, 5, 9, 8, 2, 1, 0, 4, 3},
                        {8, 7, 6, 5, 9, 3, 2, 1, 0, 4},
                        {9, 8, 7, 6, 5, 4, 3, 2, 1, 0}
                };
        static int[][] p = new int[][]
                {
                        {0, 1, 2, 3, 4, 5, 6, 7, 8, 9},
                        {1, 5, 7, 6, 2, 8, 3, 0, 9, 4},
                        {5, 8, 0, 3, 7, 9, 6, 1, 4, 2},
                        {8, 9, 1, 6, 0, 4, 3, 5, 2, 7},
                        {9, 4, 5, 3, 1, 2, 6, 8, 7, 0},
                        {4, 2, 8, 6, 5, 7, 3, 9, 0, 1},
                        {2, 7, 9, 3, 8, 0, 6, 4, 1, 5},
                        {7, 0, 4, 6, 9, 1, 3, 2, 5, 8}
                };
        int[] inv = {0, 4, 3, 2, 1, 5, 6, 7, 8, 9};

        public static boolean validateVerhoeff(String num) {
            int c = 0;
            int[] myArray = StringToReversedIntArray(num);
            for (int i = 0; i < myArray.length; i++) {
                c = d[c][p[(i % 8)][myArray[i]]];
            }

            return (c == 0);
        }

        private static int[] StringToReversedIntArray(String num) {
            int[] myArray = new int[num.length()];
            for (int i = 0; i < num.length(); i++) {
                myArray[i] = Integer.parseInt(num.substring(i, i + 1));
            }
            myArray = Reverse(myArray);
            return myArray;
        }

        private static int[] Reverse(int[] myArray) {
            int[] reversed = new int[myArray.length];
            for (int i = 0; i < myArray.length; i++) {
                reversed[i] = myArray[myArray.length - (i + 1)];
            }
            return reversed;
        }
    }

    // End of Verhoeff class
    //**************************&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&****************************************************


    // 2nd find if that particulat string is present or not
    private static int isSubstrpresent (String subStr, String superStr) {
        int retNumber = 0;
        superStr = superStr.toLowerCase();
        subStr = subStr.toLowerCase();

        superStr.replaceAll("\\s+", "");

        subStr.replaceAll("\\s+", "");
        if (superStr.indexOf(subStr) != -1) {
            retNumber++;
        }

        return retNumber;
    }

    //************************&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*******************************
    //
    public   aDet checkIfAadharPresent(String temp) {
        temp = temp.toLowerCase();
        aDet ret = new aDet();

        String name = "";
        String dob = "";
        String anum = "np";
        String gender = "";
        String[] linesws = temp.split("\n");
        String linesStr = "";

        // this loop removes unneccesary spaces
        for (int i = 0; i < linesws.length; i++) {
            if (linesws[i].length() != 0) linesStr += (linesws[i] + "\n");
        }

        linesStr = linesStr.replaceAll("government", "");
        linesStr = linesStr.replaceAll("of india", "");
        linesStr = linesStr.replaceAll("unique", "");
        linesStr = linesStr.replaceAll("identification", "");
        linesStr = linesStr.replaceAll("authority", "");
        linesStr = linesStr.replaceAll("unique identification authority", "");

        String[] lines = linesStr.split("\n");
        String lta = "";
        String ltb = "";

        ltb = linesStr;
        // NOW DOING FOR GENDER
        ltb = ltb.replaceAll("\\s+", "");
        // This regex find out gender
        if (ltb.contains("female")) gender = "female";
        if (ltb.contains("male")) gender = "male";
        if (!(ltb.contains("female") || ltb.contains("male"))) gender = "other";
        // REMOVE BRACKET HERE FOR UNCOMMENTING
        //  gender succseefully extracted


        //Crreated temporary line strings;

        for (int i = 0; i < lines.length; i++) {
            lta = lines[i];
            ltb = lines[i];
            if (ltb.contains("dob")) {

                //  dob+= "yes dob is contained";
                dob = ltb.replace("dob:", "");
                dob = dob.replace("dob", "");
                dob = dob.replaceAll(":", "");
                //dob=  dob.replaceAll("/","");
                // dob= dob.replaceAll("-","");

            }
            //trying to find out name because name is the first information in generally any card;


            lta = lta.replaceAll(" ", "");

            lta = lta.replaceAll("[^\\d.]", ""); // this removes all the non digits
            lta = lta.replaceAll("/", "");
            lta = lta.trim();
            // this loop finds out if aadhar number is present or not;
            //  anum+= "\ntesting"+lta;
            if (lta.length() == 12) {

                if (VerhoeffAlgorithm.validateVerhoeff(lta)) {
                    anum = lta;
                }
            }

            for (int j = 0; j < ltb.length(); j++) {
                if ((ltb.charAt(j) == '/') || (ltb.charAt(j) == '-')) {
                    if ((ltb.charAt(j + 3) == '/') || (ltb.charAt(j + 3) == '-')) {
                        dob = ltb.substring(j - 2, j + 7);
                    }
                }
            }

        }// remove bracket here to uncomment
        if( !anum.equals("np")) {
            String ffr = anum.substring(0, 3);
            String sfr = anum.substring(4, 7);
            String tft = anum.substring(8, 11);
            name = linesStr;
            name = name.replaceAll("name", "");
            name = name.replaceAll("name:", "");
            name = name.replaceAll(":", "");
            name = name.replaceAll("gender", "");
            name = name.replaceAll(gender, "");
            name = name.replaceAll(dob, "");
            name = name.replaceAll("dob", "");
            name = name.replaceAll(ffr, "");
            name = name.replaceAll(sfr, "");
            name = name.replaceAll(tft, "");
            name = name.replaceAll("year of birth", "");
            name = name.replaceAll("date of birth", "");
            name = name.replaceAll("[0-9]", "");
            name = name.replaceAll("\n", "");
            name = name.replaceAll("[-+^]*", "");   // this removes all the special characters
            name = name.replaceAll("/", " ");

            name = name.trim();
            name = name.toUpperCase();
            for (int i = 0; i < name.length(); i++) {
                if ((name.charAt(i) == ' ') && (name.charAt(i + 1) == ' ') && (name.charAt(i + 2) == ' ') && (name.charAt(i + 3) == ' ')) {
                    name = name.substring(0, i);
                }
            }
        }




        ret.name=name;
        ret.anum=anum;
        ret.dob=dob;
        ret.gender=gender;



        return ret;

    }

    public pDet checkPanCardDetails(String temp){
        pDet ret= new pDet();
        String str= temp;
        String num="not found",dob="not found",name="",fname="";
        str=str.replaceAll("govt of india","");
        str=str.replaceAll("income tax","");
        str=str.replaceAll("department","");
        str=str.replaceAll("income tax department","");
        str=str.replaceAll("name","");
        str=str.replaceAll("father's","");
        str=str.replaceAll("father","");
        for(String word:str.split("\\s")){
            int count=0;
            if(word.length()==10){
                //System.out.println(""+word);
                for(int i=0;i<10;i++){
                    if(i>=0&&i<=4 && word.charAt(i)>='A'&&word.charAt(i)<='Z'){
                        count++;
                    }
                    else if(i>=5 && i<=8 && word.charAt(i)>='0'&& word.charAt(i)<='9'){
                        count++;
                    }
                    else if(i==9 && word.charAt(i)>='A'&& word.charAt(i)<='Z'){
                        count++;
                    }
                }
                if(word.charAt(2)=='/'&&word.charAt(5)=='/'){
                    dob=word;
                }
            }
            if(count>=8){
                num=word;
            }
        }
        int countline=0;
        for(int i=0;i<str.length();i++){
            if(str.charAt(i)=='\n'){
                countline++;
            }
            if(countline==2&&str.charAt(i)!='\n'){
                name+=str.charAt(i);
            }
            else if(countline==3&&str.charAt(i)!='\n'){
                fname+=str.charAt(i);
            }
        }

        pDet pdetails = new pDet();
        pdetails.name = name;
        pdetails.dob = dob;
        pdetails.fname=fname;
        pdetails.pnum=num;

        return pdetails;

    }






    private String  findTypeOfString( String result) {
        String ret;

        String temp = result;
        String temp2 = temp;
        int aadharPossibility = 0;
        int panPossibility = 0;
        //panCardNumber panCardNumberStorage;

        int voterPossibility = 0;
        int others = 0;
        // String temp2=result;
        voterPossibility = voterPossibility + isSubstrpresent("Election", temp);
        voterPossibility = voterPossibility + isSubstrpresent("Elector", temp);
        voterPossibility = voterPossibility + isSubstrpresent("Elector's", temp);
        voterPossibility = voterPossibility + isSubstrpresent("Voter", temp);
        voterPossibility = voterPossibility + isSubstrpresent("Election Commission", temp);
        voterPossibility = voterPossibility + isSubstrpresent("Election Commission Of India", temp);
        voterPossibility = voterPossibility + isSubstrpresent("Elector Photo Identity", temp);

        panPossibility = panPossibility + isSubstrpresent("Income Tax", temp);
        panPossibility = panPossibility + isSubstrpresent("Tax Department ", temp);
        panPossibility = panPossibility + isSubstrpresent("Permanent Account", temp);
        panPossibility = panPossibility + isSubstrpresent("Account Number ", temp);
        panPossibility = panPossibility + isSubstrpresent("PAN", temp);
        //  panPossibility += 100*checkPanNumberPresent(temp).ispresent;

        aadharPossibility += aadharPossibility + isSubstrpresent("unique identification", temp);
        aadharPossibility += aadharPossibility + isSubstrpresent("identification authority", temp);
        aadharPossibility += aadharPossibility + isSubstrpresent("unique identification authority of india", temp);
        if(! checkIfAadharPresent(temp).anum.equals("np"))  aadharPossibility+= 1 ;

        if(panPossibility>voterPossibility&& panPossibility >aadharPossibility){
            ret="PAN";
        }
        else if( (voterPossibility>panPossibility) && (voterPossibility > aadharPossibility)){
            ret="VOTER";
        }
        else if(aadharPossibility!=0){
            ret="AADHAR";
        }
        else ret="OTHER";

        return ret;
    }

    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_id_processing);
        tv1 = (TextView) findViewById(R.id.textView);
        Button next= findViewById(R.id.idNextBtn);
        Intent configureIdDetailsIntent = new Intent(getBaseContext(),ConfigureIDDetails.class);



        Intent int1= getIntent();
        String gottenStr= int1.getStringExtra("text");


        rStr= gottenStr;
        String name="";

        String dob="";
        String number="";
        String gender="";
        String fname="";
        String type="OTHER";

        type= findTypeOfString(rStr);

        if(type.equals("AADHAR")){
            aDet anwer= checkIfAadharPresent(rStr);
            name = anwer.name;
            dob = anwer.dob;;
            //String fname =checkIfAadharPresent(rStr).;;
            number = anwer.anum;
            gender = anwer.gender;}
        else if(type.equals("PAN")){
            pDet pans= checkPanCardDetails(rStr);
            name = pans.name;
            dob = pans.dob;;
            fname =pans.fname;;
            number = pans.pnum;

        }
        else {
            // do nothing
        }
        tv1.setText(gottenStr + " type is "+ type +"name is "+name + " dob is  "+dob );
        Intent int2= new Intent(getBaseContext(),ConfigureIDDetails.class);
        int2.putExtra("name",name);
        int2.putExtra("fname",fname);
        int2.putExtra("fullstr",gottenStr);
        int2.putExtra("type",type);
        int2.putExtra("dob",dob);
        int2.putExtra("number",number);
        int2.putExtra("gender",gender);
        Timer timer= new Timer();

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                startActivity(int2);
                finish();
            }
        },100);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(int2);
                finish();
            }
        });

    }

}

