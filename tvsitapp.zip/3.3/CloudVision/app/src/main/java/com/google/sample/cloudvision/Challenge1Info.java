package com.google.sample.cloudvision;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Challenge1Info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_challenge1_info);
        Intent getInt= getIntent();
        int challengeKey= getInt.getIntExtra("challengekey",1);
    }

    public void startocrc1(View view) {
        Intent  startocrint= new Intent(getBaseContext(),MainActivity.class);
        startocrint.putExtra("Challenge",1);
        startActivity(startocrint);
        finish();

    }
}