package com.google.sample.cloudvision;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.common.io.CharStreams;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.List;

public class ACardVerificationActivity extends AppCompatActivity {
    Button uidbtn;
    Button verxmlbtn;
    String name;
    String num;
    File savedzip;
    Button btnexzip;
    String zippassword;
    EditText zippassedt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a_card_verification);

        Log.i("opening ","this has started");
        Intent recIntent = getIntent();
         name = recIntent.getStringExtra("name");
        num = recIntent.getStringExtra("num");
        name=name.toLowerCase();
        num=num.toLowerCase();
        Toast.makeText(this,"name "+name+num,Toast.LENGTH_LONG).show();


        zippassedt=findViewById(R.id.zippassword);
        uidbtn = findViewById(R.id.openAcardbtn);
        btnexzip=findViewById(R.id.btnexzip);
     //   verxmlbtn = findViewById(R.id.verxmlbtn);
        final String url = "https://resident.uidai.gov.in/offline-kyc";

        uidbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openCustomTab(url);

            }
        });



        btnexzip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dezipIntent= new Intent(Intent.ACTION_GET_CONTENT);
                dezipIntent.setType("*/*");
                //dezipIntent.addCategory(Intent.CATEGORY_OPENABLE);
                if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(getParent(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 22);
                }
                else{
                startActivityForResult(Intent.createChooser(dezipIntent,"Select a file to upload"),2);

                }
                
            }
        });

    }

    void openCustomTab(String url){
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        CustomTabsIntent customTabsIntent = builder.build();
        int colorInt = Color.parseColor("#FF0000"); //red

        builder.setToolbarColor(colorInt);
        customTabsIntent.launchUrl(this, Uri.parse(url));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==2 && resultCode==RESULT_OK){

            Uri content_describer = data.getData();
            int k=0;

            // very very important savedzip and out line should have the same path otherwise the code will simply fail
            savedzip   = new File(Environment.getExternalStorageDirectory().toString()+"/tvsapptemp.zip");
          InputStream in = null;
            OutputStream out = null;
            try {
                // open the user-picked file for reading:
                try {
                    in = getContentResolver().openInputStream(content_describer);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                // open the output-file:
              try {
                    // k=10;

                      //trying with simply savedzip it works :) :) :)
                    out = new FileOutputStream( savedzip );
                 // Toast.makeText(this,"This is out happening",Toast.LENGTH_LONG).show();
                    //  k++;
                } catch (FileNotFoundException e) {

                  Log.i("error is ",e.toString());
                 // Toast.makeText(this,"This is not out happening"+e.toString(),Toast.LENGTH_LONG).show();
                }
                // copy the content:
                byte[] buffer = new byte[1024];
                int len;
        while ((len = in.read(buffer)) != -1) {
                   out.write(buffer, 0, len);

               }
                   out.close();
          //    Toast.makeText(this,"This is happening",Toast.LENGTH_LONG).show();

              //Contents are copied!
           } catch (IOException e) {
              e.printStackTrace();
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
               if (out != null) {
                    try {
                        out.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            makeZip();
        }




    }


  //make zip
    public void makeZip() {


        //ZipFile zipfile= new ZipFile(Environment.getExternalStorageDirectory().toString()+"/verPzip.zip");
        ZipFile zipfile= new ZipFile(savedzip);
        String destination= Environment.getExternalStorageDirectory().toString()+"/extractedfolder/";
        File destfold= new File(destination);

        destfold.mkdirs();


        // Environment.getExternalStorageDirectory().mkdirs();

        ZipParameters zp = new ZipParameters();
        zp.setCompressionMethod(CompressionMethod.DEFLATE);
        zp.setCompressionLevel(CompressionLevel.NORMAL);
        zp.setEncryptFiles(true);
        //zp.setSourceExternalStream(true);
        zp.setIncludeRootFolder(true);

        zp.setEncryptionMethod(EncryptionMethod.AES);
        zp.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);
        String foldertoadd= Environment.getExternalStorageDirectory().getPath()+"/tvsapptempfolder";
        File xmllocationfolder= new File(foldertoadd);
        xmllocationfolder.mkdirs();
        try {
            if(zipfile.isEncrypted()){
            zipfile.setPassword(zippassedt.getText().toString().toCharArray());}
        } catch (ZipException e) {
            e.printStackTrace();
        }

        //till now done almost everyhting that can be done
        // now remaining the things to do are



        try {

            if(true){

                zipfile.extractAll(xmllocationfolder.getPath());
                List<FileHeader> fileHeader= zipfile.getFileHeaders();
                FileHeader fileHeader1= fileHeader.get(0);
                zipfile.renameFile(fileHeader1,"mainxml.xml");
                Toast.makeText(this,"AAdhar Card kkkkk is verified",Toast.LENGTH_LONG);
               try {
                   InputStream inputStream = zipfile.getInputStream(fileHeader1);
                   Reader reader = new InputStreamReader(inputStream);
                   String text;
                   text = CharStreams.toString(reader);
                   text=text.toLowerCase();
                   Toast.makeText(this,"AAdhar Card asdadsa is verified",Toast.LENGTH_LONG);
                   Toast.makeText(this,name+num,Toast.LENGTH_LONG).show();
                   if(text.contains(name) ){  //text.contains(name)
                     //  Toast.makeText(this,"AAdhar Card is verified"+text,Toast.LENGTH_LONG).show();
                       Intent aadharverdoneint= new Intent(getBaseContext(),Aadharverdone.class);
                       startActivity(aadharverdoneint);
                   }
                   else{
                       Toast.makeText(this,"jjjjAAdhar Card is not verified"+name+num+"\n"+text,Toast.LENGTH_LONG).show();
                   }


                //  Toast.makeText(this,text,Toast.LENGTH_LONG).show();
               }
               catch (Exception  e){
                   e.printStackTrace();
                   Toast.makeText(this,"Error noticed sdfsd"+e.toString(),Toast.LENGTH_LONG).show();
               }
                // zipfile.extractAll(Environment.getExternalStorageDirectory().getPath()+"/rajsaved2");
                Log.i("this is done","donw");
            }
            else {               Toast.makeText(this,"Select a file ",Toast.LENGTH_LONG).show();
            }


        } catch (ZipException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Toast.makeText(this,"SomeError",Toast.LENGTH_LONG).show();
        }

    }

}