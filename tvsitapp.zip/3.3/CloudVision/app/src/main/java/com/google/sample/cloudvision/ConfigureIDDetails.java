package com.google.sample.cloudvision;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ConfigureIDDetails extends AppCompatActivity {

        String[] gender = { "male", "female", "other"}; 


        static  class pDet{
        String name="";
        String pnum="";
        String fname="";
        String dob="";
    }
    // aadhar details
    static  class aDet{
        String name="";
        String dob="";
        String anum="";
        String gender="";
    }
    // voter details class
    static  class vDet{
        String name="";
        String dob="";
        String fnum="";
        String gender="";
    }

    TextView tvmain;
    EditText etname;//findViewById(R.id.editTextTextPersonName);
    EditText etnum;// findViewById(R.id.editTextNumber);
    EditText etfname;
    EditText etDate;
    Button verbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configure_i_d_details);


       verbtn=findViewById(R.id.verify);


        Intent recInt= getIntent();

        etname=findViewById(R.id.etname);
        etnum= findViewById(R.id.etnum);
        etDate=findViewById(R.id.etdate);
        etfname=findViewById(R.id.etfname);
        tvmain= findViewById(R.id.tvmain);
        String name= recInt.getStringExtra("name");
        String fname= recInt.getStringExtra("fname");
        String fstr= recInt.getStringExtra("fullstr");
        String dob= recInt.getStringExtra("dob");
        String num=recInt.getStringExtra("number");
        String type= recInt.getStringExtra("type");
        String  gender= recInt.getStringExtra("gender");
       // String gender= recInt.getStringExtra("gender");
        etname.setText(name);
        etfname.setText(fname);


        int mm,yy,dd;

        tvmain.setText(fstr);
        etnum.setText(num);
        etDate.setText(dob);
        verbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(type.contains("AADHAR") ||type.contains("aadhar")){
                    Log.i("This is happening"," ");
                    Intent veradhintent = new Intent(getBaseContext(),ACardVerificationActivity.class);
                    veradhintent.putExtra("name",etname.getText().toString());
                    veradhintent.putExtra("num",etnum.getText().toString());
                   startActivity(veradhintent);
                }
            }
        });


    }
}